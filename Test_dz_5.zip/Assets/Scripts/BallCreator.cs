using UnityEngine;

public class BallCreator : MonoBehaviour
{
    [SerializeField] private GameObject _ball;
    private GameObject _ballInSlot;

    private DisplayTabToStart _displayTabToStart;
    private BogieBallContainer _bogieBallContainer;

    private bool _firstLaunch = true;
    private bool _canLaunch = false;

    public void SetCanLaunch(bool value) { _canLaunch = value; }

    private void Awake()
    {
        _displayTabToStart = FindObjectOfType<DisplayTabToStart>();
        _bogieBallContainer = FindObjectOfType<BogieBallContainer>();
        Create();
    }

    public void Launch() 
    {
        _ballInSlot.GetComponent<FlyBall>().StartFly();
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0) && (_firstLaunch || _canLaunch))
        {
            if (_firstLaunch)
            {
                _displayTabToStart.DestroyMessage();
                _firstLaunch = false;
            }
            else
            {
                _canLaunch = false;
            }
            Launch();
        }
    }

    public void Create() 
    {
        _ballInSlot = Instantiate(_ball, transform.position, Quaternion.identity);

        BallLevel _ballInSlotBallLevel = _ballInSlot.GetComponent<BallLevel>();

        if (_ballInSlotBallLevel != null) 
        {
            _ballInSlotBallLevel.level = Random.Range(0, 3);
            _ballInSlot.GetComponent<DisplayBallLevel>().Display();
        }
    }
}
