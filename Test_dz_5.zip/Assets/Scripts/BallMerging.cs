using UnityEngine;

public class BallMerging : MonoBehaviour
{
    private BallLevel _ballLevel;
    private DisplayBallLevel _displayBallLevel;
    [SerializeField] private Collider _collider;

    [SerializeField] private GameObject _ball;

    private bool _main;

    private float _bogieYPosition;

    private void Awake() 
    {
        _bogieYPosition = FindObjectOfType<BogieMovement>().transform.position.y;
        _ballLevel = GetComponent<BallLevel>();
        _displayBallLevel = GetComponent<DisplayBallLevel>();
    }

    public bool GetMain() => _main;

    private void OnTriggerEnter(Collider collision)
    {
        if (transform.position.y < _bogieYPosition + 2f) 
        {
            BallMerging _collisionBallMerging = collision.gameObject.GetComponent<BallMerging>();
            if (_collisionBallMerging != null)
            {
                if (GetComponent<BallLevel>().level == collision.gameObject.GetComponent<BallLevel>().level)
                {
                    if (!_collisionBallMerging.GetMain()) { _main = true; }
                    if (_main)
                    {
                        Destroy(collision.gameObject);
                        _ballLevel.AddLevel();
                        _displayBallLevel.Display();
                        _collider.enabled = false;
                        _collider.enabled = true;
                    }
                }
            }
        }
    }
}
