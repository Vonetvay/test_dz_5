using UnityEngine;

public class FlyBall : MonoBehaviour
{
    [SerializeField] private Collider _collider;
    [SerializeField] private Collider _trigger;
    [SerializeField] private float _moveSpeed;
    private BogieBallContainer _bogieBallContainer;
    private BallCreator _ballCreator;

    private bool _flying;
    private Transform _target;

    private void Awake()
    {
        _ballCreator = FindObjectOfType<BallCreator>();
        _bogieBallContainer = FindObjectOfType<BogieBallContainer>();
    }

    public void StartFly()
    {
        _flying = true;
        _target = _bogieBallContainer.gameObject.transform;
    }

    private void LateUpdate()
    {
        if (_flying)
        {
            if (transform.position != _target.position) 
            {
                FlyToBogie();
            }
            else 
            {       
                _bogieBallContainer.ball = gameObject;
                Stop();
            }
            if (Input.GetMouseButtonUp(0) && _bogieBallContainer.ball == null) 
            {
                _ballCreator.SetCanLaunch(true);
                GetComponent<Rigidbody>().isKinematic = false;
                GetComponent<FlyBall>().enabled = false;
                Stop();
                _ballCreator.SetCanLaunch(true);
            }
        }
    }

    private void Stop()
    {
        _ballCreator.Create();
        _collider.enabled = true;
        _trigger.enabled = true;
        GetComponent<FlyBall>().enabled = false;
    }

    private void FlyToBogie() 
    {
        transform.position = Vector3.MoveTowards(transform.position, _target.position, _moveSpeed * Time.deltaTime);
    }
}
