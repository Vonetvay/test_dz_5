using UnityEngine;

public class BogieRayCasting : MonoBehaviour
{
    private BogieBallContainer _bogieBallContainer;
    private GameObject _copyBall;

    [SerializeField] private GameObject _tube;

    [SerializeField] private float _radius = .5f;
    [SerializeField] private float _offset = 0f;
    [SerializeField] private float _copyBallA = .5f;

    private void Awake()
    {
        _bogieBallContainer = GetComponent<BogieBallContainer>();
    }

    private void Update()
    {
        if (_bogieBallContainer.ball != null) 
        {
            if (_copyBall == null) 
            {
                _tube.SetActive(true);

                _copyBall = Instantiate(_bogieBallContainer.ball, transform.position, Quaternion.identity);

                Color _color = _copyBall.GetComponent<MeshRenderer>().material.color;
                _color.a = _copyBallA;
                _copyBall.GetComponent<MeshRenderer>().material.color = _color;

                foreach (var c in _copyBall.GetComponents<Collider>()) 
                {
                    c.enabled = false;
                }
                
            }
            Ray _ray = new Ray(transform.position, Vector3.down);
            RaycastHit _hit;
            if (Physics.SphereCast(_ray, _radius, out _hit)) 
            {
                _copyBall.transform.position = _hit.point + new Vector3(0f, _offset, 0f);
                _tube.transform.localScale = new Vector3(1f, _hit.distance / 2f, 1f);
                _tube.transform.position = _hit.point + new Vector3(0f, _hit.distance / 2f, 0f) + new Vector3(0f, _offset, 0f);
            }
        }
        else if (_copyBall != null)
        {
            _tube.SetActive(false);
            Destroy(_copyBall);
            _copyBall = null;
        }
    }
}
